# HMC5883L Compass

https://github.com/jrowberg/i2cdevlib.git
